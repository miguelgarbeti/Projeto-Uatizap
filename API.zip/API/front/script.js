/* ---------- LOGIN (index.html) ---------- */
async function realizarLogin() {
    const telefone = document.getElementById('login-telefone').value.trim();
    const senha = document.getElementById('login-senha').value;

    if (!telefone || !senha) {
        alert('Por favor, preencha o telefone e a senha.');
        return;
    }

    try {
        const url = `${API_URL}/auth?telefone=${encodeURIComponent(telefone)}&senha=${encodeURIComponent(senha)}`;

        const resposta = await fetch(url, {
            method: 'POST'
        });

        const dados = await resposta.json();

        if (resposta.ok && dados.isAuth === true) {
            localStorage.setItem('meuTelefone', telefone);
            window.location.href = 'chat.html';
        } else {
            alert('Telefone ou senha incorretos!');
        }

    } catch (erro) {
        console.error('Erro de comunicação:', erro);
        alert('Falha ao conectar com o servidor da API.');
    }
}